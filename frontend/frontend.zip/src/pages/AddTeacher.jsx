// src/pages/AddTeacher.jsx
import React, { useState } from 'react';
import {
  Container,
  TextField,
  Button,
  Typography,
  Box,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Card,
  Grid,
  Divider,
  Alert,
  Fade,
  useTheme,
  Chip
} from '@mui/material';
import {
  Person as PersonIcon,
  School as SchoolIcon,
  Save as SaveIcon,
  Badge as BadgeIcon,
  MenuBook as SubjectIcon
} from '@mui/icons-material';
import axios from 'axios';

function AddTeacher() {
  console.log("AddTeacher component rendered");
  const theme = useTheme();
  const [customId, setCustomId] = useState('');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [details, setDetails] = useState('');
  const [subject, setSubject] = useState('');
  const [teachingStandard, setTeachingStandard] = useState('');
  const [division, setDivision] = useState('');
  const [alert, setAlert] = useState({ show: false, message: '', type: 'success' });

  const showAlert = (message, type = 'success') => {
    setAlert({ show: true, message, type });
    setTimeout(() => setAlert({ show: false, message: '', type: 'success' }), 3000);
  };

  const handleAddTeacher = () => {
    console.log("Adding teacher with data:", { customId, name, email, password, details, subject, teachingStandard, division });
    axios.post('http://localhost:5000/api/users/add-teacher', {
      custom_id: customId,
      name,
      email,
      password,
      details,
      subject,
      teaching_standard: teachingStandard,
      division,
    })
      .then(response => {
        console.log("Teacher added:", response.data);
        showAlert("Teacher added successfully!");
      })
      .catch(error => {
        console.error("Error adding teacher:", error);
        showAlert("Error adding teacher", "error");
      });
  };

  return (
    <Container maxWidth="lg">
      <Box sx={{ position: 'relative', mb: 4 }}>
        {alert.show && (
          <Fade in={alert.show}>
            <Alert 
              severity={alert.type}
              sx={{ 
                position: 'absolute', 
                top: -60, 
                right: 0, 
                left: 0,
                boxShadow: 2,
                borderRadius: 2
              }}
            >
              {alert.message}
            </Alert>
          </Fade>
        )}

        <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 3 }}>
          <Typography variant="h5" sx={{ fontWeight: 600, color: 'text.primary' }}>
            Add New Teacher
          </Typography>
          <Chip 
            icon={<SchoolIcon />}
            label="Teacher Registration"
            color="primary"
            variant="outlined"
          />
        </Box>

        <Card sx={{ borderRadius: 2, boxShadow: theme.shadows[2] }}>
          <Box sx={{ p: 3 }}>
            <Grid container spacing={3}>
              {/* Basic Information Section */}
              <Grid item xs={12}>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 2 }}>
                  <BadgeIcon color="primary" />
                  <Typography variant="h6" sx={{ fontWeight: 500 }}>
                    Basic Information
                  </Typography>
                </Box>
                <Divider sx={{ mb: 2 }} />
                <Grid container spacing={2}>
                  <Grid item xs={12} md={6}>
                    <TextField
                      label="Teacher ID"
                      fullWidth
                      value={customId}
                      onChange={(e) => setCustomId(e.target.value)}
                      size="small"
                    />
                  </Grid>
                  <Grid item xs={12} md={6}>
                    <TextField
                      label="Full Name"
                      fullWidth
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      size="small"
                    />
                  </Grid>
                  <Grid item xs={12} md={6}>
                    <TextField
                      label="Email"
                      fullWidth
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      size="small"
                    />
                  </Grid>
                  <Grid item xs={12} md={6}>
                    <TextField
                      label="Password"
                      type="password"
                      fullWidth
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      size="small"
                    />
                  </Grid>
                </Grid>
              </Grid>

              {/* Teaching Information Section */}
              <Grid item xs={12}>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 2, mt: 2 }}>
                  <SubjectIcon color="primary" />
                  <Typography variant="h6" sx={{ fontWeight: 500 }}>
                    Teaching Information
                  </Typography>
                </Box>
                <Divider sx={{ mb: 2 }} />
                <Grid container spacing={2}>
                  <Grid item xs={12} md={4}>
                    <FormControl fullWidth size="small">
                      <InputLabel>Subject</InputLabel>
                      <Select
                        value={subject}
                        label="Subject"
                        onChange={(e) => setSubject(e.target.value)}
                      >
                        <MenuItem value="Maths">Maths</MenuItem>
                        <MenuItem value="Science">Science</MenuItem>
                        <MenuItem value="English">English</MenuItem>
                      </Select>
                    </FormControl>
                  </Grid>
                  <Grid item xs={12} md={4}>
                    <FormControl fullWidth size="small">
                      <InputLabel>Teaching Standard</InputLabel>
                      <Select
                        value={teachingStandard}
                        label="Teaching Standard"
                        onChange={(e) => setTeachingStandard(e.target.value)}
                      >
                        <MenuItem value="9">9</MenuItem>
                        <MenuItem value="10">10</MenuItem>
                        <MenuItem value="11">11</MenuItem>
                        <MenuItem value="12">12</MenuItem>
                      </Select>
                    </FormControl>
                  </Grid>
                  <Grid item xs={12} md={4}>
                    <FormControl fullWidth size="small">
                      <InputLabel>Division</InputLabel>
                      <Select
                        value={division}
                        label="Division"
                        onChange={(e) => setDivision(e.target.value)}
                      >
                        <MenuItem value="A">A</MenuItem>
                        <MenuItem value="B">B</MenuItem>
                        <MenuItem value="C">C</MenuItem>
                      </Select>
                    </FormControl>
                  </Grid>
                </Grid>
              </Grid>

              {/* Additional Details Section */}
              <Grid item xs={12}>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 2, mt: 2 }}>
                  <PersonIcon color="primary" />
                  <Typography variant="h6" sx={{ fontWeight: 500 }}>
                    Additional Details
                  </Typography>
                </Box>
                <Divider sx={{ mb: 2 }} />
                <Grid container spacing={2}>
                  <Grid item xs={12}>
                    <TextField
                      label="Teacher Details"
                      fullWidth
                      multiline
                      rows={4}
                      value={details}
                      onChange={(e) => setDetails(e.target.value)}
                    />
                  </Grid>
                </Grid>
              </Grid>
            </Grid>

            <Box sx={{ mt: 4, display: 'flex', justifyContent: 'flex-end' }}>
              <Button
                variant="contained"
                color="primary"
                onClick={handleAddTeacher}
                startIcon={<SaveIcon />}
                sx={{
                  px: 4,
                  py: 1,
                  borderRadius: 2,
                  textTransform: 'none',
                  fontWeight: 500
                }}
              >
                Add Teacher
              </Button>
            </Box>
          </Box>
        </Card>
      </Box>
    </Container>
  );
}

export default AddTeacher;