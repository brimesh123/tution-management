// src/pages/TakeAttendance.jsx
import React, { useState } from 'react';
import {
  Container,
  Typography,
  Box,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  TextField,
  Button,
  Table,
  TableHead,
  TableRow,
  TableCell,
  TableBody,
  Radio,
  RadioGroup,
  FormControlLabel,
  Card,
  Chip,
  Alert,
  Fade,
  useTheme,
  TableContainer,
  Paper,
  IconButton,
  Tooltip
} from '@mui/material';
import {
  Class as ClassIcon,
  CalendarToday as CalendarIcon,
  CheckCircle as PresentIcon,
  Cancel as AbsentIcon,
  Search as SearchIcon,
  Lock as LockIcon,
  LockOpen as UnlockIcon
} from '@mui/icons-material';
import axios from 'axios';

function TakeAttendance() {
  const theme = useTheme();
  const [standard, setStandard] = useState('');
  const [division, setDivision] = useState('');
  const [date, setDate] = useState('');
  const [students, setStudents] = useState([]);
  const [attendanceData, setAttendanceData] = useState({});
  const [attendanceLocked, setAttendanceLocked] = useState(false);
  const [alert, setAlert] = useState({ show: false, message: '', type: 'success' });

  const showAlert = (message, type = 'success') => {
    setAlert({ show: true, message, type });
    setTimeout(() => setAlert({ show: false, message: '', type: 'success' }), 3000);
  };

  const fetchStudents = () => {
    if (!standard || !division) {
      showAlert("Please select both standard and division", "error");
      return;
    }
    axios
      .get(`http://localhost:5000/api/users/students?standard=${standard}&division=${division}`)
      .then(response => {
        setStudents(response.data.students);
        const initialAttendance = {};
        response.data.students.forEach(student => {
          initialAttendance[student.id] = 'absent';
        });
        setAttendanceData(initialAttendance);
        showAlert("Students fetched successfully");
      })
      .catch(error => {
        console.error("Error fetching students:", error);
        showAlert("Error fetching students", "error");
      });
  };

  const handleAttendanceChange = (studentId, value) => {
    if (attendanceLocked) return;
    setAttendanceData({ ...attendanceData, [studentId]: value });
  };

  const handleSubmitAttendance = () => {
    if (!date) {
      showAlert("Please select a date", "error");
      return;
    }
    const records = students.map(student => ({
      student_id: student.id,
      status: attendanceData[student.id],
    }));
    axios.post('http://localhost:5000/api/attendance/mark-bulk', { date, attendance: records })
      .then(response => {
        showAlert("Attendance marked successfully and locked for the day!");
        setAttendanceLocked(true);
      })
      .catch(error => {
        console.error("Error marking attendance:", error);
        showAlert("Error marking attendance", "error");
      });
  };

  return (
    <Container maxWidth="lg">
      <Box sx={{ position: 'relative', mb: 4 }}>
        {alert.show && (
          <Fade in={alert.show}>
            <Alert 
              severity={alert.type}
              sx={{ 
                position: 'absolute', 
                top: -60, 
                right: 0, 
                left: 0,
                boxShadow: 2,
                borderRadius: 2
              }}
            >
              {alert.message}
            </Alert>
          </Fade>
        )}

        <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 3 }}>
          <Typography variant="h5" sx={{ fontWeight: 600, color: 'text.primary' }}>
            Take Attendance
          </Typography>
          <Chip 
            icon={<ClassIcon />}
            label={`${standard || '-'} ${division || '-'}`}
            color="primary"
            variant="outlined"
          />
          {date && (
            <Chip 
              icon={<CalendarIcon />}
              label={date}
              color="secondary"
              variant="outlined"
            />
          )}
          {attendanceLocked && (
            <Chip 
              icon={<LockIcon />}
              label="Locked"
              color="error"
              variant="outlined"
            />
          )}
        </Box>

        <Card sx={{ borderRadius: 2, boxShadow: theme.shadows[2], mb: 3 }}>
          <Box sx={{ p: 3, display: 'flex', gap: 2, alignItems: 'flex-end' }}>
            <FormControl sx={{ minWidth: 150 }} size="small">
              <InputLabel>Standard</InputLabel>
              <Select
                value={standard}
                label="Standard"
                onChange={(e) => setStandard(e.target.value)}
                disabled={attendanceLocked}
              >
                <MenuItem value="9">9</MenuItem>
                <MenuItem value="10">10</MenuItem>
                <MenuItem value="11">11</MenuItem>
                <MenuItem value="12">12</MenuItem>
              </Select>
            </FormControl>
            <FormControl sx={{ minWidth: 150 }} size="small">
              <InputLabel>Division</InputLabel>
              <Select
                value={division}
                label="Division"
                onChange={(e) => setDivision(e.target.value)}
                disabled={attendanceLocked}
              >
                <MenuItem value="A">A</MenuItem>
                <MenuItem value="B">B</MenuItem>
                <MenuItem value="C">C</MenuItem>
              </Select>
            </FormControl>
            <TextField
              label="Date"
              type="date"
              size="small"
              InputLabelProps={{ shrink: true }}
              value={date}
              onChange={(e) => setDate(e.target.value)}
              disabled={attendanceLocked}
              sx={{ minWidth: 200 }}
            />
            <Button 
              variant="contained" 
              onClick={fetchStudents} 
              disabled={attendanceLocked}
              startIcon={<SearchIcon />}
              sx={{ 
                px: 3,
                py: 1,
                borderRadius: 2,
                textTransform: 'none'
              }}
            >
              Fetch Students
            </Button>
          </Box>
        </Card>

        {students.length > 0 && (
          <Card sx={{ borderRadius: 2, boxShadow: theme.shadows[2] }}>
            <TableContainer>
              <Table>
                <TableHead>
                  <TableRow sx={{ bgcolor: 'background.default' }}>
                    <TableCell sx={{ fontWeight: 600 }}>Student ID</TableCell>
                    <TableCell sx={{ fontWeight: 600 }}>Name</TableCell>
                    <TableCell sx={{ fontWeight: 600 }}>Standard</TableCell>
                    <TableCell sx={{ fontWeight: 600 }}>Division</TableCell>
                    <TableCell sx={{ fontWeight: 600 }}>Attendance</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {students.map(student => (
                    <TableRow 
                      key={student.id}
                      sx={{ 
                        '&:hover': { bgcolor: 'action.hover' },
                        transition: 'background-color 0.2s'
                      }}
                    >
                      <TableCell>
                        <Chip 
                          label={student.custom_id}
                          size="small"
                          variant="outlined"
                        />
                      </TableCell>
                      <TableCell>{student.name}</TableCell>
                      <TableCell>{student.standard}</TableCell>
                      <TableCell>{student.division}</TableCell>
                      <TableCell>
                        <RadioGroup
                          row
                          value={attendanceData[student.id]}
                          onChange={(e) => handleAttendanceChange(student.id, e.target.value)}
                        >
                          <FormControlLabel
                            value="present"
                            control={
                              <Radio 
                                disabled={attendanceLocked}
                                icon={<PresentIcon color="action" />}
                                checkedIcon={<PresentIcon color="success" />}
                              />
                            }
                            label="Present"
                          />
                          <FormControlLabel
                            value="absent"
                            control={
                              <Radio 
                                disabled={attendanceLocked}
                                icon={<AbsentIcon color="action" />}
                                checkedIcon={<AbsentIcon color="error" />}
                              />
                            }
                            label="Absent"
                          />
                        </RadioGroup>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
            
            <Box sx={{ p: 2, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <Typography variant="body2" color="text.secondary">
                Total Students: {students.length}
              </Typography>
              {!attendanceLocked ? (
                <Button 
                  variant="contained" 
                  color="primary" 
                  onClick={handleSubmitAttendance}
                  startIcon={<UnlockIcon />}
                  sx={{ 
                    px: 4,
                    py: 1,
                    borderRadius: 2,
                    textTransform: 'none'
                  }}
                >
                  Submit & Lock Attendance
                </Button>
              ) : (
                <Typography 
                  variant="body1" 
                  color="success.main"
                  sx={{ 
                    display: 'flex', 
                    alignItems: 'center', 
                    gap: 1,
                    fontWeight: 500
                  }}
                >
                  <LockIcon fontSize="small" />
                  Attendance locked for {date}
                </Typography>
              )}
            </Box>
          </Card>
        )}
      </Box>
    </Container>
  );
}

export default TakeAttendance;