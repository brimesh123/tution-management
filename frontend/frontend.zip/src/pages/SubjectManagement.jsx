// src/pages/SubjectManagement.jsx
import React, { useState, useEffect } from 'react';
import { Container, TextField, Button, Typography, Box, FormControl, InputLabel, Select, MenuItem, Table, TableHead, TableRow, TableCell, TableBody, Paper } from '@mui/material';
import axios from 'axios';

function SubjectManagement() {
  const [standard, setStandard] = useState('');
  const [subjectName, setSubjectName] = useState('');
  const [subjects, setSubjects] = useState([]);

  const handleAddSubject = () => {
    if (!standard || !subjectName) {
      alert("Please fill in both standard and subject name");
      return;
    }
    axios.post('http://localhost:5000/api/subjects/add', { standard, subject_name: subjectName })
      .then(response => {
        alert("Subject added successfully!");
        setSubjectName('');
        fetchSubjects();
      })
      .catch(error => {
        console.error("Error adding subject:", error);
        alert("Error adding subject");
      });
  };

  const fetchSubjects = () => {
    if (!standard) return;
    axios.get(`http://localhost:5000/api/subjects?standard=${standard}`)
      .then(response => {
        setSubjects(response.data.subjects);
      })
      .catch(error => {
        console.error("Error fetching subjects:", error);
      });
  };

  useEffect(() => {
    if (standard) {
      fetchSubjects();
    }
  }, [standard]);

  return (
    <Container>
      <Typography variant="h5" gutterBottom>Subject Management</Typography>
      <Box sx={{ mt: 2 }}>
        <FormControl fullWidth margin="normal">
          <InputLabel id="standard-select-label">Select Standard</InputLabel>
          <Select
            labelId="standard-select-label"
            value={standard}
            label="Select Standard"
            onChange={(e) => setStandard(e.target.value)}
          >
            <MenuItem value="9">9</MenuItem>
            <MenuItem value="10">10</MenuItem>
            <MenuItem value="11">11</MenuItem>
            <MenuItem value="12">12</MenuItem>
          </Select>
        </FormControl>
        <TextField
          label="Subject Name"
          fullWidth
          margin="normal"
          value={subjectName}
          onChange={(e) => setSubjectName(e.target.value)}
        />
        <Button variant="contained" onClick={handleAddSubject}>Add Subject</Button>
      </Box>
      <Paper sx={{ mt: 4 }}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>ID</TableCell>
              <TableCell>Subject Name</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {subjects.map((subj) => (
              <TableRow key={subj.id}>
                <TableCell>{subj.id}</TableCell>
                <TableCell>{subj.subject_name}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </Paper>
    </Container>
  );
}

export default SubjectManagement;
