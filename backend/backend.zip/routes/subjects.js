// routes/subjects.js
const express = require('express');
const router = express.Router();
const db = require('../db');

// Add a subject for a given standard
router.post('/add', async (req, res) => {
  const { standard, subject_name } = req.body;
  if (!standard || !subject_name) {
    return res.status(400).json({ message: "Standard and subject name are required" });
  }
  try {
    const [result] = await db.promise().query(
      'INSERT INTO subjects (standard, subject_name) VALUES (?, ?)',
      [standard, subject_name]
    );
    res.status(201).json({ message: "Subject added successfully", subjectId: result.insertId });
  } catch (error) {
    console.error("Error adding subject:", error);
    res.status(500).json({ message: "Server error" });
  }
});

// Get subjects for a given standard
router.get('/', async (req, res) => {
  const { standard } = req.query;
  if (!standard) {
    return res.status(400).json({ message: "Standard is required" });
  }
  try {
    const [rows] = await db.promise().query(
      'SELECT * FROM subjects WHERE standard = ?',
      [standard]
    );
    res.json({ subjects: rows });
  } catch (error) {
    console.error("Error fetching subjects:", error);
    res.status(500).json({ message: "Server error" });
  }
});

module.exports = router;
