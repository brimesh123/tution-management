// routes/attendance.js
const express = require('express');
const router = express.Router();
const db = require('../db');


// In routes/attendance.js
router.get('/day', async (req, res) => {
    const { date } = req.query;
    if (!date) {
      return res.status(400).json({ message: "Date is required" });
    }
    try {
      const [rows] = await db.promise().query(
        `SELECT DISTINCT a.student_id, u.name, u.standard, u.division, a.attendance_date, a.status 
         FROM attendance a 
         JOIN users u ON a.student_id = u.id
         WHERE a.attendance_date = ?`,
        [date]
      );
      res.json({ attendance: rows });
    } catch (error) {
      console.error("Error fetching attendance:", error);
      res.status(500).json({ message: "Server error" });
    }
  });
  



// Endpoint to mark attendance
router.post('/mark', async (req, res) => {
  const { student_id, attendance_date, status } = req.body;
  console.log('Received attendance mark request:', req.body);
  if (!student_id || !attendance_date || !status) {
    console.log('Missing fields in attendance mark request');
    return res.status(400).json({ message: 'Missing fields' });
  }
  try {
    const [result] = await db.promise().query(
      'INSERT INTO attendance (student_id, attendance_date, status) VALUES (?, ?, ?)',
      [student_id, attendance_date, status]
    );
    console.log('Attendance record created with ID:', result.insertId);
    res.status(201).json({ message: 'Attendance marked successfully', recordId: result.insertId });
  } catch (error) {
    console.error('Error marking attendance:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

router.post('/mark-bulk', async (req, res) => {
    // Expect body: { date, attendance: [ { student_id, status } ] }
    const { date, attendance } = req.body;
    if (!date || !attendance || !Array.isArray(attendance)) {
      return res.status(400).json({ message: "Date and an attendance array are required" });
    }
    try {
      const queries = attendance.map(record => {
        return db.promise().query(
          'INSERT INTO attendance (student_id, attendance_date, status) VALUES (?, ?, ?)',
          [record.student_id, date, record.status]
        );
      });
      await Promise.all(queries);
      res.status(201).json({ message: "Attendance marked successfully" });
    } catch (error) {
      console.error("Error marking bulk attendance:", error);
      res.status(500).json({ message: "Server error" });
    }
  });

// Endpoint to fetch attendance records for a student
router.get('/:studentId', async (req, res) => {
  const { studentId } = req.params;
  console.log('Fetching attendance records for student:', studentId);
  try {
    const [rows] = await db.promise().query(
      'SELECT * FROM attendance WHERE student_id = ?',
      [studentId]
    );
    console.log('Attendance records fetched:', rows.length);
    res.json({ attendance: rows });
  } catch (error) {
    console.error('Error fetching attendance:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;
